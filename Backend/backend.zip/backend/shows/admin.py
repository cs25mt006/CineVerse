from django.contrib import admin
from .models import Show

admin.site.register(Show)
